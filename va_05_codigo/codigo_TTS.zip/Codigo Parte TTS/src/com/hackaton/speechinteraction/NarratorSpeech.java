package com.hackaton.speechinteraction;

import java.util.Locale;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;

public class NarratorSpeech implements OnInitListener{

	// Sintetizador de habla
	private String text;
	private TextToSpeech tts;

	//Obtenemos el mensaje
	public NarratorSpeech( Context cont, String message){
		text = message;
		tts = new TextToSpeech(cont,this);
	}

	@Override
	public void onInit(int status) {
		if (status == TextToSpeech.SUCCESS) {
			// Idioma a emplear por el sintetizador
			int result = tts.setLanguage(new Locale("es"));

			if ( (result == TextToSpeech.LANG_MISSING_DATA) ||
				 (result == TextToSpeech.LANG_NOT_SUPPORTED) ) {
				// Idioma no disponible
				System.out.println("No disponible");
			} else {
				// Sintetizador operativo
				// Sintetizamos el mensaje (eliminamos posibles mensajes de
				// la cola)
				tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
			}
		} else {
				// Error en la inicializaci�n
				System.out.println("Error: imposible inicializar TTS");
		}
	}
	
}