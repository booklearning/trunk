package com.hackaton.speechinteraction;

import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;


public class SoundPlayer {

	private MediaPlayer mp;
	public SoundPlayer(){

	}
	
	public boolean isPlaying(){
		return mp.isPlaying();
	}
	
	public void startAudio(AssetFileDescriptor afd){
		    //set up MediaPlayer    
		    mp = new MediaPlayer();
		    
		    try {
		        //mp.setDataSource(path+file);
		        mp.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
		        mp.prepare();
		        mp.start();
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}

	public void stopAudio(){
		if (mp != null && mp.isPlaying()){
			mp.stop();
		}
	}
}