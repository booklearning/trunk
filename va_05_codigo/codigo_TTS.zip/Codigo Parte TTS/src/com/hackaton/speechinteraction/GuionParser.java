package com.hackaton.speechinteraction;

import java.io.IOException;
import java.io.InputStream;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class GuionParser {

   private String titulo;
   private String escena;
   private String voz;
   private String moral;
   private InputStream guion;
   private XmlPullParserFactory pullParserFactory;
   
   public GuionParser(InputStream inputGuion){
      this.guion = inputGuion;
   }
   public String getTitulo(){
      return this.titulo;
   }
   public String getEscena(){
      return this.escena;
   }
   public String getVoz(){
      return this.voz;
   }
   public String getMoral(){
      return this.moral;
   }

   public void parseXML() throws XmlPullParserException, IOException{
		pullParserFactory = XmlPullParserFactory.newInstance();
		XmlPullParser parser = pullParserFactory.newPullParser();
		
		parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
        parser.setInput(guion, null);

        parseXML(parser);
   }
   
	private void parseXML(XmlPullParser parser) throws XmlPullParserException,IOException
	{
       int eventType = parser.getEventType();

       while (eventType != XmlPullParser.END_DOCUMENT){
           String name = null;
           switch (eventType){
               case XmlPullParser.START_TAG:
                   name = parser.getName();
                   if (name.equals("title")){
                	      this.titulo = parser.nextText();
                   } else if (name.equals("scene")){
                	      this.escena = parser.nextText();
                   } else if (name.equals("voice")){
                	      this.voz = parser.nextText();
                   } else if (name.equals("moral")){
                	      this.moral = parser.nextText();
                   }
            	break;    
           }
           eventType = parser.next();
       }
	}
}