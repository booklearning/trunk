package com.hackaton.speechinteraction;

import java.util.ArrayList;
import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.view.Window;
import android.view.WindowManager;

public class SoundDetector extends Activity implements OnInitListener {

	// C�digo para identificar la invocaci�n y el resultado
	private static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;
	private static final int RECORDER_SAMPLERATE = 8000;
	private static final int RECORDER_CHANNELS = AudioFormat.CHANNEL_IN_MONO;
	private static final int RECORDER_AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT;
	
	//Grabador de Audio
	private int blow_value;
	private AudioRecord ar = null;
	private boolean isRecording = false;
	
	// Sintetizador de habla
	private TextToSpeech tts;
	private boolean ttsReady = false;
	private boolean recognited = true;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 // quitar el t�tulo
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // pantalla completa
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);     
		
		// Inicializamos TTS
		tts = new TextToSpeech(this, this);
		startTTS();
		setContentView(R.layout.activity_recognition);
	}
	
	public boolean isRecognited() {
		return recognited;
	}
	
	public boolean startRecording()
    {
		int minSize = AudioRecord.getMinBufferSize(RECORDER_SAMPLERATE, RECORDER_CHANNELS, RECORDER_AUDIO_ENCODING);
		System.out.println("BUFFER SIZE VALUE IS " + minSize);
		ar = new AudioRecord(MediaRecorder.AudioSource.MIC, RECORDER_SAMPLERATE, RECORDER_CHANNELS, RECORDER_AUDIO_ENCODING,minSize);
        short[] buffer = new short[minSize];
        
        ar.startRecording();
        isRecording = true;
        while(isRecording)
        {
            ar.read(buffer, 0, minSize);
            for (short s : buffer) 
            {
            	if (Math.abs(s) > 27000)   //DETECT VOLUME (IF I BLOW IN THE MIC)
                {
                    blow_value = Math.abs(s);
                    System.out.println("Blow Value="+ blow_value);
                    ar.stop();
        	        ar.release();
        	        
        	        return true;
                }
            }
        }
        ar.stop();
        ar.release();
        
        return false;
    }
	
	@Override
	public void onInit(int status) {
		if (status == TextToSpeech.SUCCESS) {
			// Idioma a emplear por el sintetizador
			int result = tts.setLanguage(new Locale("es"));
			if (result == TextToSpeech.LANG_MISSING_DATA
					|| result == TextToSpeech.LANG_NOT_SUPPORTED) {
				// Idioma no disponible
				ttsReady = false;
			} else {
				// Sintetizador operativo
				ttsReady = true;
			}
		} else {
			// Error en la inicializaci�n
			ttsReady = false;
		}
	}
	
	// Se inicia el reconocimiento de habla (lanza intent)
	public void startTTS(){
		startVoiceRecognitionActivity();
	}
	
	private void startVoiceRecognitionActivity() {
		Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
		
		// Especificamos el paquete que llama para identificar nuestra aplicaci�n
		intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, 
				getClass().getPackage().getName());

		// Mensaje que se mostrar� al usuario
		intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
				"Por favor, hable alto y claro");

		// Modelo a emplear por el reconocedor.
		// - habla en formato libre --> LANGUAGE_MODEL_FREE_FORM
		intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
				RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

		// Indicamos el n�mero de resultados a obtener
		// Est�n ordenados en orden de confianza del reconocedor
		intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
		startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
		}
		
	// Obtenemos el resultado del Reconocimiento
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if ( (requestCode == VOICE_RECOGNITION_REQUEST_CODE) &&
				 (resultCode == RESULT_OK)) {
			// Si todo ha ido bien procesamos el comando
			ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
			if (matches.size() > 0) {
				// Obtenemos la mejor hip�tesis del reconocedor
				String res = matches.get(0);
				// Sintetizamos el comando (eliminamos posibles mensajes de
				// la cola)
				if (ttsReady) {
					tts.speak(res, TextToSpeech.QUEUE_FLUSH, null);
				}

				String tok[] = res.split(" ");
				String piropo = tok[0];
					
				// Lugar
				if (piropo.compareTo("guapa") == 0) {
					recognited = true;
				}
			}
		}
		this.finish();
		//super.onActivityResult(requestCode, resultCode, data);	
	}
	
	@Override
	protected void onDestroy(){
	    //Cierra la libreria TTS
	    if(tts != null) {
	        tts.stop();
	        tts.shutdown();
	    }
	    super.onDestroy();
	}
}