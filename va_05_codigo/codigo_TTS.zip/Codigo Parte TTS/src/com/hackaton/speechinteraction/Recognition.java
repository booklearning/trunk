package com.hackaton.speechinteraction;

import java.io.IOException;
import java.io.InputStream;

import org.xmlpull.v1.XmlPullParserException;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/**
 * Clase principal para probar las funcionalidades de TTS, para el proyecto bookleARning 
 * @author GhostMasters
 *
 */
public class Recognition extends Activity  {
    /** Called when the activity is first created. */
	
	private static final String TAG = Recognition.class.getSimpleName();
	
	private SoundDetector sound = new SoundDetector();
	private SoundPlayer player = new SoundPlayer();
	private AssetFileDescriptor afd;

	private InputStream is;
	private GuionParser obj;
	private String msg = "";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // quitar el t�tulo
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // pantalla completa
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);     
		AssetManager assetManager = getBaseContext().getAssets();
        try {
			afd = getAssets().openFd("Astucia.mp3");
		} catch (IOException e) {
			e.printStackTrace();
		}
        try {
			is = assetManager.open("Voces.txt");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
        try {
			obj = new GuionParser(is);
			obj.parseXML();
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        setContentView(R.layout.activity_recognition); 
        Log.d(TAG, "View added");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.recognition, menu);
        return true;
    }
    
	@Override
	protected void onDestroy() {
		Log.d(TAG, "Destroying...");
		super.onDestroy();
	}

	@Override
	protected void onStop() {
		Log.d(TAG, "Stopping...");
		super.onStop();
	}
	
	/** Invocado al pulsar el bot�n Soplar */
	public void BlowRecon(View view) {
		if (sound.startRecording()) System.out.println("SOPLA");
    }
 
    /** Invocado al pulsar el bot�n Reconocer */
    public void reconocerMessage(View view) {
    	Intent intent = new Intent(this, SoundDetector.class);
    	startActivity(intent);
		if (sound.isRecognited()) System.out.println("RECONOCIDO");
    }
    
    /** Invocado al pulsar el bot�n ASR */
    public void SpeechRecogn(View view) {
        msg = obj.getMoral();
		NarratorSpeech nar = new NarratorSpeech(this, msg );
    }
    
    /** Invocado al pulsar el bot�n Play */
    public void PlaySound(View view) {
    	player.startAudio(afd);
    }
    
    /** Invocado al pulsar el bot�n Stop */
    public void StopSound(View view) {
    	player.stopAudio();
    }
}