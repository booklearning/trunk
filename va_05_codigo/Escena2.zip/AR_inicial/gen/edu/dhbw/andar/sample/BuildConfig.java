/** Automatically generated file. DO NOT MODIFY */
package edu.dhbw.andar.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}