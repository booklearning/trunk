package edu.dhbw.andar.sample;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLUtils;
import android.util.Log;
import edu.dhbw.andar.ARObject;

/*
 * A cube with texture. 
 * Define the vertices for only one representative face.
 * Render the cube by translating and rotating the face.
 */
public class Zorra extends ARObject {

	public Zorra(String name, String patternName, double markerWidth,
			double[] markerCenter) {
		super(name, patternName, markerWidth, markerCenter);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void init(GL10 arg0) {
		// TODO Auto-generated method stub
		
	}
	
}