package edu.dhbw.andar.sample;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Debug;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import edu.dhbw.andar.ARToolkit;
import edu.dhbw.andar.AndARActivity;
import edu.dhbw.andar.Config;
import edu.dhbw.andar.exceptions.AndARException;
import edu.dhbw.andobjviewer.graphics.CustomObject;
import edu.dhbw.andobjviewer.graphics.Model3D;
import edu.dhbw.andobjviewer.models.Model;
import edu.dhbw.andobjviewer.parser.ObjParser;
import edu.dhbw.andobjviewer.parser.ParseException;
import edu.dhbw.andobjviewer.util.AssetsFileUtil;
import edu.dhbw.andobjviewer.util.BaseFileUtil;

/**
 * Example of an application that makes use of the AndAR toolkit.
 * 
 * @author Tobi
 * 
 */
public class CustomActivity extends AndARActivity {

	Model3D someObject2;
	CustomObject someObject;
	Model3D someObject4;
	ARToolkit artoolkit;

	/* Menu Options: */
	private final int MENU_SCALE = 0;
	private final int MENU_ROTATE = 1;
	private final int MENU_TRANSLATE = 2;
	private final int MENU_SCREENSHOT = 3;

	private int mode = MENU_ROTATE;
	private Model model;
	private Model3D model3d;

	private int cargar = 0;

	private ProgressDialog waitDialog;
	
	private Context context;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		CustomRenderer renderer = new CustomRenderer();// optional, may be set
														// to null
		//CustomRenderer2 renderer2=new CustomRenderer2();
		super.setNonARRenderer(renderer);// or might be omited
		getSurfaceView().setOnTouchListener(new TouchEventHandler());
		
		context=this;

		// register a object for each marker type
		artoolkit = super.getArtoolkit();
		new ModelLoader().execute("scene01.obj","hiro.pat");
		

	}

	private class ModelLoader extends AsyncTask<String, Void, Void> {

		/*
		 * private Model model; private Model3D model3d;
		 */

		@Override
		protected Void doInBackground(String... params) {

			Intent intent = getIntent();
			Bundle data = intent.getExtras();
			// int type = data.getInt("type");
			// String modelFileName = data.getString("name");
			String modelFileName = params[0];
			BaseFileUtil fileUtil = null;
			File modelFile = null;
			fileUtil = new AssetsFileUtil(getResources().getAssets());
			fileUtil.setBaseFolder("models/");

			// read the model file:
			if (modelFileName.endsWith(".obj")) {
				ObjParser parser = new ObjParser(fileUtil);
				try {
					if (Config.DEBUG)
						Debug.startMethodTracing("AndObjViewer");

					if (fileUtil != null) {
						BufferedReader fileReader = fileUtil
								.getReaderFromName(modelFileName);
						if (fileReader != null) {
							model = parser.parse("Model", fileReader);
							model3d = new Model3D(model, params[1],context);
						}
					}
					if (Config.DEBUG)
						Debug.stopMethodTracing();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			// waitDialog.dismiss();

			// register model
			try {
				/*
				 * CustomObject someObject = new CustomObject("CuboVerde",
				 * "barcode.patt", 80.0, new double[] { 0, 0 });
				 * artoolkit.registerARObject(someObject);
				 */
				//Log.d("GOHS", "asdjlkasjdlk");
				if (model3d != null)
					artoolkit.registerARObject(model3d);
				
			} catch (AndARException e) {
				e.printStackTrace();
			}
			startPreview();
		}
	}

	/**
	 * Handles touch events.
	 * 
	 * @author Tobias Domhan
	 * 
	 */
	class TouchEventHandler implements OnTouchListener {

		private float lastX = 0;
		private float lastY = 0;

		/*
		 * handles the touch events. the object will either be scaled,
		 * translated or rotated, dependen on the current user selected mode.
		 * 
		 * @see android.view.View.OnTouchListener#onTouch(android.view.View,
		 * android.view.MotionEvent)
		 */
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			/*if (model != null) {
				switch (event.getAction()) {
				// Action started
				default:
				case MotionEvent.ACTION_DOWN:
					lastX = event.getX();
					lastY = event.getY();
					break;
				// Action ongoing
				case MotionEvent.ACTION_MOVE:
					float dX = lastX - event.getX();
					float dY = lastY - event.getY();
					lastX = event.getX();
					lastY = event.getY();
					if (model != null) {
						switch (mode) {
						case MENU_SCALE:
							model.setScale(dY / 100.0f);
							break;
						case MENU_ROTATE:
							model.setXrot(-1 * dX);// dY-> Rotation um die
													// X-Achse
							model.setYrot(-1 * dY);// dX-> Rotation um die
													// Y-Achse
							break;
						case MENU_TRANSLATE:
							model.setXpos(dY / 10f);
							model.setYpos(dX / 10f);
							break;
						}
					}
					break;
				// Action ended
				case MotionEvent.ACTION_CANCEL:
				case MotionEvent.ACTION_UP:
					lastX = event.getX();
					lastY = event.getY();
					break;
				}
			}*/
			return true;
		}

	}

	/**
	 * Inform the user about exceptions that occurred in background threads.
	 * This exception is rather severe and can not be recovered from. TODO
	 * Inform the user and shut down the application.
	 */
	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		Log.e("AndAR EXCEPTION", ex.getMessage());
		finish();
	}

}
