package edu.dhbw.andar.sample;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLUtils;
import android.util.Log;

/*
 * A cube with texture. 
 * Define the vertices for only one representative face.
 * Render the cube by translating and rotating the face.
 */
public class Nubes {
	private FloatBuffer vertexBuffer; // Buffer for vertex-array
	private FloatBuffer texBuffer; // Buffer for texture-coords-array (NEW)

	private int numFaces = 1;

	private int texture = 0;
	private int movimiento=-5;
	private float[] vertices = { // Vertices for a face
	-1.0f, -1.0f, 0.0f, // 0. left-bottom-front
			1.0f, -1.0f, 0.0f, // 1. right-bottom-front
			-1.0f, 1.0f, 0.0f, // 2. left-top-front
			1.0f, 1.0f, 0.0f // 3. right-top-front
	};

	float[] texCoords = { // Texture coords for the above face (NEW)
	0.0f, 1.0f, // A. left-bottom (NEW)
			1.0f, 1.0f, // B. right-bottom (NEW)
			0.0f, 0.0f, // C. left-top (NEW)
			1.0f, 0.0f // D. right-top (NEW)
	};
	int[] textureIDs = new int[numFaces]; // Array for 1 texture-ID (NEW)
	private Bitmap[] bitmap = new Bitmap[numFaces];
	private int[] imageFileIDs = { // Image file IDs
	R.raw.nuve};

	// Constructor - Set up the buffers
	public Nubes(Context context) {
		// Setup vertex-array buffer. Vertices in float. An float has 4 bytes
		ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
		vbb.order(ByteOrder.nativeOrder()); // Use native byte order
		vertexBuffer = vbb.asFloatBuffer(); // Convert from byte to float
		vertexBuffer.put(vertices); // Copy data into buffer
		vertexBuffer.position(0); // Rewind

		for (int face = 0; face < numFaces; face++) {
			bitmap[face] = BitmapFactory.decodeStream(context.getResources()
					.openRawResource(imageFileIDs[face]));
		}

		// Setup texture-coords-array buffer, in float. An float has 4 bytes
		// (NEW)
		ByteBuffer tbb = ByteBuffer.allocateDirect(texCoords.length * 4);
		tbb.order(ByteOrder.nativeOrder());
		texBuffer = tbb.asFloatBuffer();
		texBuffer.put(texCoords);
		texBuffer.position(0);
	}

	// Draw the shape
	public void draw(GL10 gl) {
		gl.glFrontFace(GL10.GL_CCW); // Front face in counter-clockwise
										// orientation
		gl.glEnable(GL10.GL_CULL_FACE); // Enable cull face
		gl.glCullFace(GL10.GL_BACK); // Cull the back face (don't display)

		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY); // Enable
		gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, texBuffer); // Define
		
		gl.glPushMatrix();
		gl.glTranslatef(movimiento, 5.0f, -5.0f);
		gl.glScalef(2.0f,2.0f,2.0f);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, textureIDs[0]);
		gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, 4);
		gl.glPopMatrix();

		Log.d("COSAS",""+textureIDs[0]);

		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY); // Disable
																// texture-coords-array
																// (NEW)
		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisable(GL10.GL_CULL_FACE);


		if (movimiento<10)
			movimiento++;
		if (movimiento == 10)
			movimiento = -5;
	
	}

	// Load an image into GL texture
	public void loadTexture(GL10 gl, Context context) {
		
		gl.glGenTextures(numFaces, textureIDs, 0); // Generate texture-ID array


		// Generate OpenGL texture images
		for (int face = 0; face < numFaces; face++) {
		
			gl.glBindTexture(GL10.GL_TEXTURE_2D, textureIDs[face]); 
			GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bitmap[face], 0);

			bitmap[face].recycle();
			gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER,
					GL10.GL_NEAREST);
			gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER,
					GL10.GL_LINEAR);

		}
	}
}